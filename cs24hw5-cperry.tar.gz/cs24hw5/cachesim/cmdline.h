#include "membase.h"

void usage(const char *progname);
membase_t * make_cached_memory(int argc, const char **argv, uint32_t mem_size);

